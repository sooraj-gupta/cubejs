var settings = 
{
	//Set to false to disable loading
	"load": true,
	//Loading time in rotations
	"rotations": 3
}