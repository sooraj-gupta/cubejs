var settings = 
{
	//Set to false to disable loading
	"load": true,
	//Loading time in (millis)
	"time": 2700
}