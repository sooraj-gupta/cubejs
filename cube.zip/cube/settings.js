/* 
 * ALL CODE BY: SOORAJ GUPTA
 * COPYRIGHT © 2020 SOORAJ GUPTA
 * Last Updated: December 2020
 */

var settings = 
{
	//Set to false to disable loading
	"load": true,
	//Loading time in rotations
	"rotations": 3
}